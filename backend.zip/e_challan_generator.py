from reportlab.pdfgen import canvas
from datetime import datetime
import os

CHALLAN_DIR = "challans"
os.makedirs(CHALLAN_DIR, exist_ok=True)

def generate_challan(vehicle_number, violation_type, speed, image_path=None, camera_id="CAM01"):
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"{CHALLAN_DIR}/challan_{vehicle_number}_{timestamp}.pdf"

    c = canvas.Canvas(filename)
    c.setFont("Helvetica-Bold", 14)
    c.drawString(100, 800, "Smart Traffic E-Challan")

    c.setFont("Helvetica", 12)
    c.drawString(50, 760, f"Vehicle Number: {vehicle_number}")
    c.drawString(50, 740, f"Violation: {violation_type}")
    c.drawString(50, 720, f"Speed: {speed:.2f} km/h")
    c.drawString(50, 700, f"Camera ID: {camera_id}")
    c.drawString(50, 680, f"Date & Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    if image_path and os.path.exists(image_path):
        c.drawImage(image_path, 50, 500, width=200, height=150)

    c.showPage()
    c.save()
    return filename
