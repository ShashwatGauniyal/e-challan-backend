from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

from traffic_api import router as traffic_router
from safety_alert_api import router as safety_router
from violation_store import get_all_violations
from multi_camera_processor import start_all_cameras, start_signal_updater
from stats_manager import stats

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Start camera threads + signal logic
camera_sources = {
    "CAM1": "cameras/v.mp4",
    "CAM2": "cameras/cam2.mp4",
    "CAM3": "cameras/cam3.mp4",
    "CAM4": "cameras/cam4.mp4",
}
start_all_cameras(camera_sources)
start_signal_updater()

# Mount routers
app.include_router(traffic_router)
app.include_router(safety_router)

@app.get("/api/stats")
def get_stats():
    return stats.get_stats()

@app.get("/api/challans")
def fetch_all_challans():
    return get_all_violations()

@app.get("/api/challans/download")
def download_challan(pdf_path: str):
    return FileResponse(path=pdf_path, filename=pdf_path.split("/")[-1])
