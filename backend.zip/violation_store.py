from datetime import datetime

violation_log = []

def log_violation(vehicle, violation_type, speed, pdf_path):
    violation_log.append({
        "vehicle": vehicle,
        "type": violation_type,
        "speed": speed,
        "pdf": pdf_path,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    })

def get_all_violations():
    return violation_log
