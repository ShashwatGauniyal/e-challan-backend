import cv2
import threading
import time
from collections import defaultdict
from speed_estimator import SpeedEstimator

# Shared dictionaries for vehicle counts and traffic signals
vehicle_counts = defaultdict(int)
traffic_lights = {}
fps_lookup = {}

# Dummy object detector and tracker (to be replaced with actual model)
def detect_and_track_objects(frame):
    # Replace this with actual detection + tracking code
    return [{"id": 1, "bbox": (50, 50, 150, 150)}]

def process_camera(cam_id, video_path):
    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS)
    fps_lookup[cam_id] = fps
    estimator = SpeedEstimator(fps)

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        tracked_objects = detect_and_track_objects(frame)
        vehicle_counts[cam_id] = len(tracked_objects)
        frame = estimator.update(tracked_objects, frame)

        # OPTIONAL: Display feed
        # cv2.imshow(cam_id, frame)
        # if cv2.waitKey(1) & 0xFF == ord('q'):
        #     break

    cap.release()
    vehicle_counts[cam_id] = 0

def start_all_cameras(camera_sources):
    for cam_id, path in camera_sources.items():
        thread = threading.Thread(target=process_camera, args=(cam_id, path), daemon=True)
        thread.start()

def update_traffic_signals():
    while True:
        if vehicle_counts:
            max_lane = max(vehicle_counts, key=vehicle_counts.get)
            for cam in vehicle_counts:
                traffic_lights[cam] = "GREEN" if cam == max_lane else "RED"
        time.sleep(10)  # update every 10 seconds

def start_signal_updater():
    thread = threading.Thread(target=update_traffic_signals, daemon=True)
    thread.start()
